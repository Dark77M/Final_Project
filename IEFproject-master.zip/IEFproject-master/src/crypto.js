"use strict";
exports.__esModule = true;
exports.generateMnemonicPrivateKey = void 0;
var mnGen = require('mngen');
var hasha = require("hasha");
function sha256(word) {
    return hasha(word, { algorithm: 'sha256', encoding: 'hex' });
}
//I will use di function to create my wallet
function generateMnemonicPrivateKey() {
    var mnemonic = mnGen.list(4); //random strings ['home', 'bye', 'bike', 'pen']
    console.log("Write down those mnemonic words that are used to generate your private key " + mnemonic);
    var hashes = [];
    mnemonic.map(function (word) { hashes.push(sha256(word)); });
    var tmp_result1 = sha256(sha256(hashes[0]) + sha256(hashes[1]));
    var tmp_result2 = sha256(sha256(hashes[2]) + sha256(hashes[3]));
    var privateKey = sha256(sha256(tmp_result1) + sha256(tmp_result2));
    return privateKey;
}
exports.generateMnemonicPrivateKey = generateMnemonicPrivateKey;
