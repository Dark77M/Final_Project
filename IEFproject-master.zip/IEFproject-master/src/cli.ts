import * as readlineSync from 'readline-sync'
import {MOSAIC_NAME} from './wallet'
import { async } from 'hasha';
import {loadWallet} from './storage';
import {getBalance, createAccount,testTransaction} from './wallet';
import {sendmlts, createmlts} from './multif';

const Cfont = require('cfonts');
const clear = require('clear');
var colors = require('colors/safe');

async function cmdBalance(){
    const wallet = await loadWallet();
    await getBalance(wallet.address);
    loadCli()
}

function cmdCreatAccount(){
    createAccount();
    loadCli()
}

function cmdAccountMultisign(){
    createmlts();
    loadCli();
}

async function cmdSendCoins(){
    await testTransaction();
    loadCli()
}

function cmdMultisignTransaction(){
    sendmlts();
    loadCli();
}

function loadCli(){
    setTimeout(() => {
        back();
    }, 1000);    
}

async function back(){
        if (readlineSync.keyInYN('go back?')){
        cli();
    } else {
        process.exit();
    }
}



const enum Commands {
    create = 'CREATE',
    balance = 'BALANCE',
    transaction = 'TRANSACTION',
    createMultisign = 'NEW MULTISIGNATURE ACCOUNT',
    multisignTransaction = 'NEW MULTISIGNATURE TRANSACTION',
    close = 'CLOSE',    
}

export function cli() {
    clear();

    Cfont.say(`COVIDCOIND`, {gradient: 'blue,red', align:'center'});

    console.log(colors.blue.underline(`Command line Interface for ${MOSAIC_NAME} powered by Ali & Martina.`));
 
    var menu = require('readline-sync'),
    Command = [
        Commands.create,
        Commands.transaction,
        Commands.balance,
        Commands.createMultisign,
        Commands.multisignTransaction,
        Commands.close
    ],

        index = menu.keyInSelect(Command, 'Commands');

    switch (Command[index]){
     case Commands.create:
         cmdCreatAccount();
        break;
     case Commands.transaction:
         cmdSendCoins();
        break;
     case Commands.balance:
         cmdBalance();
         break;
     case Commands.createMultisign:
         cmdAccountMultisign();
        break;
     case Commands.multisignTransaction:
         cmdMultisignTransaction();
        break;
     case Commands.close:
         process.exit()
        break;
      default:
          cli();
          break;   
    }
};