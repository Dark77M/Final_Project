import {
  NetworkType,
Account,
SimpleWallet,
Password,
RepositoryFactoryHttp,
Address,
AccountInfo,
TransactionService,
TransactionHttp,
TransferTransaction,
AggregateTransaction,
HashLockTransaction,
Mosaic,
MosaicId,
UInt64,
Deadline,
PlainMessage,
MultisigAccountModificationTransaction,
PublicAccount,
SignedTransaction,
TransactionAnnounceResponse,
} from 'symbol-sdk';
import * as readlineSync from 'readline-sync';
var colors = require('colors/safe');
import {storeSecrets, Secrets, loadAccount} from './storage';
import {generateMnemonicPrivateKey} from './crypto';
export const NETWORKTYPE = NetworkType.TEST_NET;


export const MOSAIC_NAME = 'covidcoin';
const HELP = 'martina.canonaco98@gmail.com or alihbek@outlook.com';
const MOSAIC_ID_COVIDCOIN = '05D6A80DE3C9ADCA';//7E7E69F892357A30
const covidcoin_divisibility = 0;//TAFJFJ-NUFXTC-CW35BW-RIBOPP-KREPTQ-B4XHVF-UXQ4
const nodeUrl = 'http://api-01.eu-central-1.testnet-0951-v1.symboldev.network:3000';
const repositoryFactory = new RepositoryFactoryHttp(nodeUrl);
const accountHttp = repositoryFactory.createAccountRepository();
const old_generationHash = 'D6ECA9D0EC77760CF63C24F8C52F05E6C4F6E415E4A6E1B39FA28FD3F071A048';
const generationHash ='4009619EB7A9F824C5D0EE0E164E0F99CCD7906A475D7768FD60B452204BD0A2';
const transactionRepository = repositoryFactory.createTransactionRepository();
const receiptHttp = repositoryFactory.createReceiptRepository();
const transactionHttp = repositoryFactory.createTransactionRepository();
const transactionService = new TransactionService(transactionHttp, receiptHttp);
const listener = repositoryFactory.createListener();


export async function sendCoins(): Promise<boolean> {
    return new Promise<boolean>(async (resolve, reject) => {
      const account = await loadAccount();
  
      const rawRecipientAddress = readlineSync.question(
        '\nWallet address [ex. TB..]: '
      ); // TBMXSZXAEK7X6JC4XB7R5Y4JGPWNBALTBTYV4KAK
  
      const recipientAddress = Address.createFromRawAddress(rawRecipientAddress);
  
      const rawAmount = readlineSync.question(`\n${MOSAIC_NAME} to send: `);
      const amount = parseInt(rawAmount);
      const textToSend = readlineSync.question('\nText to send: ');
  
      const rawTx = createTransaction(
        recipientAddress.pretty(),
        amount,
        textToSend
      );
      const signedTx = signTransaction(account, rawTx);
  
      await doTransaction(signedTx);
  
      console.log(
        colors.green(
          `\n Transfered ${amount} ${MOSAIC_NAME} from ${account.address.pretty()} to address: ${recipientAddress.pretty()}`
        )
      );
  
      let checkURL = `\nTranscation link: ${nodeUrl}/transaction/${signedTx.hash}/status \n`;
      console.log(checkURL);
  
      try {
        resolve(true);
      } catch {
        reject(false);
      }
    });
  }

// creating a Transaction
export function createTransaction(rawRecipientAddress: string, amount: number, text: string): TransferTransaction
{
    const recipientAddress = Address.createFromRawAddress(rawRecipientAddress);
    const currency = new MosaicId(MOSAIC_ID_COVIDCOIN);

    const transferTransaction = TransferTransaction.create(
        Deadline.create(),
        recipientAddress,
        [new Mosaic(currency, UInt64.fromUint(amount*Math.pow(10,covidcoin_divisibility)))],
        PlainMessage.create(text),
        NETWORKTYPE,
        UInt64.fromUint(10),
        );
       
    return transferTransaction;
}

// sign the Transaction
function signTransaction(
    account: Account,
    tx: TransferTransaction
  ): SignedTransaction {
    return account.sign(tx, generationHash);
  }
  
  
  // Announce the transaction to the network
  async function doTransaction(signedTx: SignedTransaction): Promise<void> {
          transactionRepository.announce(signedTx).subscribe(
        (tx) => console.log(tx),
         // console.log(`\nTransaction info: ${tx.message}\n`);
        
        (err: Error) => 
      
            console.log
              `\nIt was not possible to do the transfer. Error: ${err}\n`
          );      



         
     }
  

export async function testTransaction(): Promise<boolean>
{
    return new Promise<boolean> ( async (resolve, reject) =>
    {
      const recipientAddress = readlineSync.question('\nWallet Address [ex..TB]:');
      //TB6LOZUBF2XUUJDKAVLXYCIDQ2U4GI57EOPFWLI4

      const rewAmount = readlineSync.question(`\n${MOSAIC_NAME} to send: `)
      const textToSend = readlineSync.question('\nText to send:')

        const account = await loadAccount();
        //user will write in input these datas
       
        const amount = parseInt(rewAmount);
       
    
        const rawTx = createTransaction(recipientAddress,amount,textToSend);
        const signedTx = signTransaction(account, rawTx);
    
        await doTransaction(signedTx)
        
        try{
            resolve(true)
        } catch {
            reject(false)
        }
    });    
}

export async function getBalance(address: Address): Promise<boolean> {
  return new Promise<boolean>((resolve, reject) => {
    accountHttp.getAccountInfo(address).subscribe((accountInfo) => {
      let mosaics = accountInfo.mosaics;
      let mosaic = mosaics.find(
        (mosaic) => mosaic.id.toHex() == MOSAIC_ID_COVIDCOIN
      );

      if (mosaic) {
        console.log(
          colors.yellow(
            `\nYou have ${mosaic.amount.toString()} ${MOSAIC_NAME} in your wallet`
          )
        );
      } else {
        console.log(
          colors.red(`\n You have 0 ${MOSAIC_NAME} in your balance.`)
        );
        console.log(
          colors.red(`\n You could ask to ${HELP} for some ${MOSAIC_NAME}`)
        );
      }
      resolve(true);
    }),
      (err: Error) => {
        reject(
          console.log(
            `An error was happening and it was not possible to check the balance: ${err}`
          )
        );
      };
  });
}


export function createAccount() {
    console.log(
      colors.yellow(`\nPlease enter an unique passord (8 character minumum).\n`)
    );
  
    let inputPassword = readlineSync.questionNewPassword(`\nInput a Password: `, {
      min: 8,
      max: 12,
    });
    const password = new Password(inputPassword);
  
    let walletName = readlineSync.question('\nGive to the wallet a name: ');
  
    const priv_key = generateMnemonicPrivateKey();
  
    const wallet = SimpleWallet.createFromPrivateKey(
      walletName,
      password,
      priv_key,
      NETWORKTYPE
    );
  
    const secret: Secrets = {
      password: password,
      privateKey: priv_key,
      walletName: walletName,
    };
  
    console.log(
      colors.blue(
        `A new wallet is generated with address: ${wallet.address.pretty()}`
      )
    ); // TCGCYI-IOBQQB-M7P7DW-SAA2FT-AQG67E-YRJZVN-EGZ7
  
    console.log(
      colors.yellow(`You can now start to send and receive ${MOSAIC_NAME}`)
    );
  
    storeSecrets(secret);
  }
  